function goToBookingForm() {
    window.location.href = "book-room.html";
}

function goToAvailability() {
    window.location.href = "check-availability.html";
}

function goToMyBookings() {
    window.location.href = "my-bookings.html";
}

function goToStats() {
    window.location.href = "admin-panel.html";
}

function goToSettings() {
    window.location.href = "settings.html";
}
  